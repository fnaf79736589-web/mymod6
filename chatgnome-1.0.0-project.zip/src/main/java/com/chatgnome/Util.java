package com.chatgnome;

import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.registries.ForgeRegistries;

final class Util {
    private Util() {}

    static Predicate<BlockState> matcher(String spec) {
        if (spec.startsWith("#")) {
            TagKey<Block> tag = TagKey.create(Registries.BLOCK, new ResourceLocation(spec.substring(1)));
            return st -> st.is(tag);
        }
        ResourceLocation rl = new ResourceLocation(spec.contains(":") ? spec : "minecraft:" + spec);
        if (!ForgeRegistries.BLOCKS.containsKey(rl)) throw new IllegalArgumentException("Невідомий блок: " + spec);
        Block b = ForgeRegistries.BLOCKS.getValue(rl);
        return st -> st.is(b);
    }

    static String itemId(ItemStack s) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        return id == null ? "?" : id.toString();
    }

    static String normId(String s) { return s.contains(":") ? s : "minecraft:" + s; }

    /** Текст першого рядка таблички, що висить на сундуку (або порожньо). */
    static String label(Level lv, BlockPos pos) {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos sp = pos.relative(d);
            BlockState ss = lv.getBlockState(sp);
            if (ss.getBlock() instanceof WallSignBlock && ss.getValue(WallSignBlock.FACING) == d
                    && lv.getBlockEntity(sp) instanceof SignBlockEntity sign) {
                String t = sign.getFrontText().getMessage(0, false).getString();
                if (!t.isBlank()) return t.trim();
            }
        }
        return "";
    }

    /** Якщо гном застряг у породі після режиму привида — виносить його на поверхню. */
    static void surface(GnomeEntity g) {
        Level lv = g.level();
        if (lv.noCollision(g.getBoundingBox())) return;
        int y = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, g.getBlockX(), g.getBlockZ());
        g.moveTo(g.getX(), y, g.getZ());
    }

    static void leaveGhost(GnomeEntity g) {
        if (g.isBuildMode()) {
            g.setBuildMode(false);
            surface(g);
        }
    }
}
