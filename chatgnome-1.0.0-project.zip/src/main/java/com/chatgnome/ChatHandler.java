package com.chatgnome;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ChatHandler {

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("gnome")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("apikey")
                        .then(Commands.argument("key", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    Config.API_KEY.set(StringArgumentType.getString(ctx, "key").trim());
                                    Config.API_KEY.save();
                                    ctx.getSource().sendSuccess(() -> Component.literal("API ключ збережено."), false);
                                    return 1;
                                }))));
    }

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String text = event.getRawText().trim();
        String rest = stripPrefix(text);
        if (rest == null) return;

        GnomeEntity gnome = findGnome(player);
        if (gnome == null) {
            player.sendSystemMessage(Component.literal(
                    "<Гном> Поруч нема твого гнома. Викличи його яйцем і клікни по ньому правою кнопкою, щоб стати власником."));
            return;
        }
        if (rest.isBlank()) {
            gnome.say("Слухаю! Напиши, що зробити.");
            return;
        }
        String low = rest.toLowerCase(Locale.ROOT).replaceAll("[.!\\s]+$", "");
        if (low.equals("стоп") || low.equals("stop") || low.equals("відміна") || low.equals("скасуй")) {
            gnome.clearTasks();
            gnome.say("Зупинився.");
            return;
        }

        String context = buildContext(player, gnome);
        MinecraftServer server = player.getServer();
        gnome.say("Думаю...");
        final String request = rest;
        CompletableFuture.runAsync(() -> {
            try {
                String reply = LlmClient.ask(Prompt.SYSTEM, context + "\nЗавдання від гравця: " + request);
                JsonObject plan = LlmClient.parsePlan(reply);
                server.execute(() -> apply(gnome, player, plan));
            } catch (Exception ex) {
                server.execute(() -> gnome.say("Помилка: " + ex.getMessage()));
            }
        });
    }

    /** Повертає текст команди без звертання або null, якщо повідомлення не до гнома. */
    private static String stripPrefix(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String p : Config.PREFIXES.get()) {
            String pl = p.toLowerCase(Locale.ROOT);
            if (!lower.startsWith(pl)) continue;
            String rest = text.substring(pl.length());
            if (!rest.isEmpty() && Character.isLetterOrDigit(rest.charAt(0))) continue;
            return rest.replaceFirst("^[\\s,:;.!\\-—]+", "").trim();
        }
        return null;
    }

    private static GnomeEntity findGnome(ServerPlayer p) {
        List<GnomeEntity> list = p.serverLevel().getEntitiesOfClass(GnomeEntity.class,
                p.getBoundingBox().inflate(256),
                g -> p.getUUID().equals(g.getOwnerId()));
        return list.stream().min(Comparator.comparingDouble(g -> g.distanceToSqr(p))).orElse(null);
    }

    private static String buildContext(ServerPlayer p, GnomeEntity g) {
        return "Context: player at x=" + p.getBlockX() + " y=" + p.getBlockY() + " z=" + p.getBlockZ()
                + ", facing " + p.getDirection().getName().toUpperCase(Locale.ROOT)
                + "; gnome at x=" + g.getBlockX() + " y=" + g.getBlockY() + " z=" + g.getBlockZ()
                + "; gnome inventory: " + g.inventorySummary()
                + "; requireMaterials=" + Config.REQUIRE_MATERIALS.get() + ".";
    }

    private static void apply(GnomeEntity g, ServerPlayer p, JsonObject plan) {
        if (!g.isAlive()) return;
        String say = JsonUtil.gets(plan, "say", "");
        List<Tasks.Task> tasks = new ArrayList<>();
        try {
            if (plan.has("plan") && plan.get("plan").isJsonArray()) {
                for (JsonElement e : plan.getAsJsonArray("plan")) {
                    tasks.add(Tasks.fromJson(e.getAsJsonObject(), p));
                }
            }
        } catch (Exception ex) {
            g.say("Не зміг зрозуміти план: " + ex.getMessage());
            return;
        }
        if (!say.isBlank()) g.say(say);
        g.clearTasks();
        tasks.forEach(g::enqueue);
    }
}
