package com.chatgnome;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

/** Складає повний план будівництва (блок -> стан) для багатоповерхового будинку з підвалами. */
public final class HouseBuilder {
    private HouseBuilder() {}

    public static final class Pen {
        public String entity;
        public double x, y, z;
    }

    public static final class Plan {
        final LinkedHashMap<Long, BlockState> ops = new LinkedHashMap<>();
        final LinkedHashMap<Long, BlockState> late = new LinkedHashMap<>();
        public final Map<Long, String[]> signs = new HashMap<>();
        public final List<Pen> pens = new ArrayList<>();
        public final List<String> notes = new ArrayList<>();
        public BlockPos doorOutside;
        public int animalsPer = 4;
        public AABB bounds;
        public long[] keys;
        public BlockState[] states;

        void put(int x, int y, int z, BlockState s) { ops.put(BlockPos.asLong(x, y, z), s); }

        void putLate(int x, int y, int z, BlockState s) { late.put(BlockPos.asLong(x, y, z), s); }

        boolean free(int x, int y, int z) {
            BlockState s = ops.get(BlockPos.asLong(x, y, z));
            return s == null || s.isAir();
        }

        void freeze() {
            int n = ops.size() + late.size();
            keys = new long[n];
            states = new BlockState[n];
            int i = 0;
            for (Map.Entry<Long, BlockState> e : ops.entrySet()) { keys[i] = e.getKey(); states[i++] = e.getValue(); }
            for (Map.Entry<Long, BlockState> e : late.entrySet()) { keys[i] = e.getKey(); states[i++] = e.getValue(); }
            ops.clear();
            late.clear();
        }

        public int size() { return keys.length; }
    }

    static final class Lv {
        int w, l, h, base, minX, minZ;
        String type = "empty";
        boolean underground;

        int ix0() { return minX + 1; }
        int ix1() { return minX + w - 2; }
        int iz0() { return minZ + 1; }
        int iz1() { return minZ + l - 2; }
        int y0() { return base + 1; }
        int y1() { return base + h; }
        int ceil() { return base + h + 1; }
    }

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private static JsonArray defaultFloors() {
        return JsonParser.parseString(
                "[{\"width\":15,\"length\":15,\"height\":5,\"type\":\"living\"},"
                        + "{\"width\":19,\"length\":19,\"height\":6,\"type\":\"machines\"}]").getAsJsonArray();
    }

    static Block stairsFor(Block mat) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(mat);
        if (id != null) {
            String p = id.getPath();
            String[] cands = {p + "_stairs", p.replace("_bricks", "_brick") + "_stairs", p.replace("bricks", "brick") + "_stairs"};
            for (String c : cands) {
                ResourceLocation rl = new ResourceLocation(id.getNamespace(), c);
                if (ForgeRegistries.BLOCKS.containsKey(rl)) return ForgeRegistries.BLOCKS.getValue(rl);
            }
        }
        return Blocks.STONE_BRICK_STAIRS;
    }

    public static Plan plan(ServerLevel level, JsonObject spec, BlockPos pp, Direction facing) {
        Plan p = new Plan();
        Block mat = JsonUtil.block(spec, "material", "minecraft:stone_bricks");
        BlockState M = mat.defaultBlockState();
        BlockState ST = stairsFor(mat).defaultBlockState().setValue(StairBlock.FACING, Direction.EAST);
        BlockState GLASS = Blocks.GLASS.defaultBlockState();
        boolean windows = JsonUtil.getb(spec, "windows", true);
        boolean lighting = JsonUtil.getb(spec, "lighting", true);
        List<String> animals = JsonUtil.strList(spec, "animal_pens", true);
        boolean sub = !animals.isEmpty();
        boolean basement = JsonUtil.getb(spec, "basement", false) || sub;
        List<String> customLabels = JsonUtil.strList(spec, "chest_labels", false);
        p.animalsPer = JsonUtil.clamp(JsonUtil.geti(spec, "animals_per_pen", 4), 1, 12);

        JsonArray fa = (spec.has("floors") && spec.get("floors").isJsonArray()) ? spec.getAsJsonArray("floors") : defaultFloors();
        int nf = Math.min(fa.size(), Config.MAX_FLOORS.get());
        if (nf < 1) throw new IllegalArgumentException("Потрібен хоча б один поверх.");

        // ---- рівні знизу вгору: [сховище звірів], [підвал], поверхи
        List<Lv> L = new ArrayList<>();
        int under = (sub ? 1 : 0) + (basement ? 1 : 0);
        for (int i = 0; i < under; i++) {
            Lv u = new Lv();
            u.h = 4;
            u.underground = true;
            u.type = (sub && i == 0) ? "pens" : "storage";
            L.add(u);
        }
        int maxH = 4;
        for (int i = 0; i < nf; i++) {
            JsonObject f = fa.get(i).getAsJsonObject();
            Lv v = new Lv();
            v.w = JsonUtil.geti(f, "width", 15);
            v.l = JsonUtil.geti(f, "length", 15);
            v.h = JsonUtil.clamp(JsonUtil.geti(f, "height", 4), 3, 12);
            v.type = JsonUtil.gets(f, "type", "empty").toLowerCase();
            maxH = Math.max(maxH, v.h);
            L.add(v);
        }
        int maxRise = maxH + 1;
        int minDim = Math.max(11, maxRise + 6);
        boolean resized = false;
        for (int i = under; i < L.size(); i++) {
            Lv v = L.get(i);
            int w = JsonUtil.clamp(v.w, minDim, 61), l = JsonUtil.clamp(v.l, minDim, 61);
            if (w != v.w || l != v.l) resized = true;
            v.w = w;
            v.l = l;
        }
        if (resized) p.notes.add("Розміри скоригував (мінімум " + minDim + " і максимум 61), щоб влізли сходи.");
        Lv g0 = L.get(under);
        for (int i = 0; i < under; i++) { L.get(i).w = g0.w; L.get(i).l = g0.l; }

        // ---- положення на мапі
        int cx, cz;
        if (spec.has("x") && spec.has("z")) {
            cx = JsonUtil.geti(spec, "x", pp.getX()) + g0.w / 2;
            cz = JsonUtil.geti(spec, "z", pp.getZ()) + g0.l / 2;
        } else if (facing.getAxis() == Direction.Axis.X) {
            cx = pp.getX() + facing.getStepX() * (5 + g0.w / 2);
            cz = pp.getZ();
        } else {
            cx = pp.getX();
            cz = pp.getZ() + facing.getStepZ() * (5 + g0.l / 2);
        }
        for (Lv v : L) {
            v.minX = cx - v.w / 2;
            v.minZ = cz - v.l / 2;
        }
        int y0 = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);
        g0.base = y0 - 1;
        for (int i = under - 1; i >= 0; i--) L.get(i).base = L.get(i + 1).base - (L.get(i).h + 1);
        for (int i = under + 1; i < L.size(); i++) L.get(i).base = L.get(i - 1).base + L.get(i - 1).h + 1;
        Lv top = L.get(L.size() - 1);
        if (top.ceil() >= level.getMaxBuildHeight() - 2) {
            throw new IllegalArgumentException("Не вистачає висоти світу для стількох поверхів. Зменш кількість або висоту.");
        }
        if (L.get(0).base < level.getMinBuildHeight() + 3) {
            throw new IllegalArgumentException("Тут надто низько для підвалів. Обери вище місце.");
        }

        // ---- сходова клітка (спільна для всіх рівнів)
        int Xs = Integer.MIN_VALUE, Zs = Integer.MIN_VALUE, maxIx = Integer.MAX_VALUE, maxIz = Integer.MAX_VALUE;
        for (Lv v : L) {
            Xs = Math.max(Xs, v.ix0());
            Zs = Math.max(Zs, v.iz0() + 1);
            maxIx = Math.min(maxIx, v.ix1());
            maxIz = Math.min(maxIz, v.iz1());
        }
        if (Xs + maxRise + 1 > maxIx || Zs + 1 > maxIz) {
            throw new IllegalArgumentException("Поверхи надто різні за розмірами, сходи не влізуть. Зроби розміри ближчими.");
        }

        // ---- двері на боці, що дивиться на гравця
        Direction dd = facing.getOpposite();
        int doorX, doorZ;
        switch (dd) {
            case SOUTH -> { doorZ = g0.minZ + g0.l - 1; doorX = g0.minX + g0.w / 2; }
            case NORTH -> { doorZ = g0.minZ; doorX = g0.minX + g0.w / 2; }
            case EAST -> { doorX = g0.minX + g0.w - 1; doorZ = g0.minZ + g0.l / 2; }
            default -> { doorX = g0.minX; doorZ = g0.minZ + g0.l / 2; }
        }
        p.doorOutside = new BlockPos(doorX + dd.getStepX() * 2, y0, doorZ + dd.getStepZ() * 2);

        BlockState TORCH = Blocks.TORCH.defaultBlockState();

        for (int i = 0; i < L.size(); i++) {
            Lv v = L.get(i);
            Lv prev = i > 0 ? L.get(i - 1) : null;
            boolean last = i == L.size() - 1;
            int x0 = v.minX, x1 = v.minX + v.w - 1, z0 = v.minZ, z1 = v.minZ + v.l - 1;

            // 1) розчистка простору (тільки де є що прибирати)
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    for (int y = v.y0(); y <= v.y1(); y++) {
                        if (!level.getBlockState(new BlockPos(x, y, z)).isAir()) p.put(x, y, z, AIR);
                    }
                }
            }
            // 2) підлога/стеля (разом з попереднім рівнем)
            rect(p, x0, z0, x1, z1, v.base, M);
            if (prev != null) rect(p, prev.minX, prev.minZ, prev.minX + prev.w - 1, prev.minZ + prev.l - 1, v.base, M);
            if (i == 0 && !v.underground) {
                for (int x = x0; x <= x1; x++) {
                    for (int z = z0; z <= z1; z++) {
                        for (int y = v.base - 1, c = 0; c < 30; y--, c++) {
                            BlockState s = level.getBlockState(new BlockPos(x, y, z));
                            if (!s.isAir() && s.getFluidState().isEmpty() && s.canOcclude()) break;
                            p.put(x, y, z, M);
                        }
                    }
                }
            }
            // 3) сходи з попереднього рівня
            if (prev != null) {
                int rise = prev.h + 1, yb = prev.base + 1;
                for (int j = 0; j < rise; j++) p.put(Xs + j, yb + j, Zs, ST);
                p.put(Xs + rise - 3, v.base, Zs, AIR);
                p.put(Xs + rise - 2, v.base, Zs, AIR);
            }
            // 4) стіни
            for (int y = v.y0(); y <= v.y1(); y++) {
                for (int x = x0; x <= x1; x++) { p.put(x, y, z0, M); p.put(x, y, z1, M); }
                for (int z = z0; z <= z1; z++) { p.put(x0, y, z, M); p.put(x1, y, z, M); }
            }
            // 5) вікна
            if (windows && !v.underground && v.h >= 4) {
                int wy = v.y0() + 1;
                for (int dy = 0; dy < 2; dy++) {
                    for (int x = x0 + 2; x < x1 - 1; x += 4) { p.put(x, wy + dy, z0, GLASS); p.put(x, wy + dy, z1, GLASS); }
                    for (int z = z0 + 2; z < z1 - 1; z += 4) { p.put(x0, wy + dy, z, GLASS); p.put(x1, wy + dy, z, GLASS); }
                }
            }
            // 6) двері (отвір без полотна) на першому поверсі
            if (i == under) {
                p.put(doorX, v.y0(), doorZ, AIR);
                p.put(doorX, v.y0() + 1, doorZ, AIR);
            }
            // 7) дах
            if (last) rect(p, x0, z0, x1, z1, v.ceil(), M);

            // 8) наповнення за типом
            switch (v.type) {
                case "storage" -> { if (v.underground) storage(p, v, Xs, maxRise, customLabels); }
                case "pens" -> pens(p, v, Xs, maxRise, animals);
                case "living" -> {
                    BlockState foot = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.NORTH).setValue(BedBlock.PART, BedPart.FOOT);
                    BlockState head = foot.setValue(BedBlock.PART, BedPart.HEAD);
                    for (int bx : new int[]{v.ix1() - 1, v.ix1() - 4}) {
                        if (bx > Xs + maxRise + 2) {
                            p.put(bx, v.y0(), v.iz0() + 2, foot);
                            p.put(bx, v.y0(), v.iz0() + 1, head);
                        }
                    }
                }
                case "machines" -> {
                    int sx = v.minX + v.w / 2;
                    p.putLate(sx, v.y0() + 1, v.iz0(), Blocks.OAK_WALL_SIGN.defaultBlockState().setValue(WallSignBlock.FACING, Direction.SOUTH));
                    p.signs.put(BlockPos.asLong(sx, v.y0() + 1, v.iz0()), new String[]{"Механізми", "Industrial", "Upgrade"});
                }
                default -> { }
            }
            // 9) освітлення наземних поверхів
            if (lighting && !v.underground) {
                for (int x = v.ix0() + 1; x <= v.ix1(); x += 5) {
                    for (int z = v.iz0() + 1; z <= v.iz1(); z += 5) {
                        boolean inStairs = x >= Xs - 1 && x <= Xs + maxRise + 1 && z >= Zs - 1 && z <= Zs + 1;
                        if (!inStairs && p.free(x, v.y0(), z)) p.put(x, v.y0(), z, TORCH);
                    }
                }
            }
        }

        int minXAll = Integer.MAX_VALUE, minZAll = Integer.MAX_VALUE, maxXAll = Integer.MIN_VALUE, maxZAll = Integer.MIN_VALUE;
        for (Lv v : L) {
            minXAll = Math.min(minXAll, v.minX);
            minZAll = Math.min(minZAll, v.minZ);
            maxXAll = Math.max(maxXAll, v.minX + v.w);
            maxZAll = Math.max(maxZAll, v.minZ + v.l);
        }
        p.bounds = new AABB(minXAll, L.get(0).base, minZAll, maxXAll, top.ceil() + 1, maxZAll);
        p.freeze();
        return p;
    }

    private static void rect(Plan p, int x0, int z0, int x1, int z1, int y, BlockState s) {
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) p.put(x, y, z, s);
    }

    private static String[] signLines(int k, List<String> custom) {
        if (k < custom.size()) return new String[]{custom.get(k), ""};
        int n = Categories.NAMES.size();
        return new String[]{Categories.NAMES.get(k % n), "№" + (k / n + 1)};
    }

    private static void placeDouble(Plan p, int x, int y, int z, Direction f) {
        BlockState a = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, f).setValue(ChestBlock.TYPE, ChestType.LEFT);
        if (ChestBlock.getConnectedDirection(a) != Direction.EAST) a = a.setValue(ChestBlock.TYPE, ChestType.RIGHT);
        ChestType other = a.getValue(ChestBlock.TYPE) == ChestType.LEFT ? ChestType.RIGHT : ChestType.LEFT;
        BlockState b = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, f).setValue(ChestBlock.TYPE, other);
        p.put(x, y, z, a);
        p.put(x + 1, y, z, b);
    }

    /** Підвал: ряди подвійних сундуків у 2 яруси, між ними проходи, на кожному сундуку табличка. */
    private static void storage(Plan p, Lv v, int Xs, int maxRise, List<String> custom) {
        int ix0 = v.ix0(), ix1 = v.ix1(), iz0 = v.iz0(), iz1 = v.iz1(), y0 = v.y0();
        int cx0 = Xs + maxRise + 3;
        int k = 0;
        BlockState sign = Blocks.OAK_WALL_SIGN.defaultBlockState();
        for (int z = iz0; z <= iz1; z++) {
            int r = (z - iz0) % 3;
            if (r == 1) continue;
            Direction f = (r == 0) ? Direction.SOUTH : Direction.NORTH;
            int fz = z + f.getStepZ();
            if (fz < iz0 || fz > iz1) continue;
            for (int x = cx0; x + 1 <= ix1; x += 2) {
                for (int layer = 0; layer < 2; layer++) {
                    int y = y0 + layer;
                    placeDouble(p, x, y, z, f);
                    int sx = (r == 0) ? x : x + 1;
                    p.putLate(sx, y, fz, sign.setValue(WallSignBlock.FACING, f));
                    p.signs.put(BlockPos.asLong(sx, y, fz), signLines(k++, custom));
                }
            }
        }
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        for (int z = iz0 + 1; z <= iz1; z += 3) {
            for (int x = ix0 + 1; x <= ix1; x += 4) {
                if (p.free(x, v.y1(), z)) p.put(x, v.y1(), z, lantern);
            }
        }
        for (int z = iz0 + 1; z <= iz1; z += 4) {
            for (int x = ix0 + 1; x < cx0; x += 4) {
                if (p.free(x, v.y1(), z)) p.put(x, v.y1(), z, lantern);
            }
        }
    }

    /** Нижній рівень: загони з огорожі та воротами до центрального проходу. */
    private static void pens(Plan p, Lv v, int Xs, int maxRise, List<String> animals) {
        int ix0 = v.ix0(), ix1 = v.ix1(), iz0 = v.iz0(), iz1 = v.iz1(), y0 = v.y0();
        int pw = 7;
        int px0 = Xs + maxRise + 3;
        int cz = iz0 + (iz1 - iz0 + 1) / 2;
        int cols = (ix1 - px0 + 1) / pw;
        List<int[]> slots = new ArrayList<>(); // {px, zA, zB, northRow}
        if (cols >= 1) {
            if (cz - 1 - iz0 + 1 >= 5) for (int c = 0; c < cols; c++) slots.add(new int[]{px0 + c * pw, iz0, cz - 1, 1});
            if (iz1 - (cz + 1) + 1 >= 5) for (int c = 0; c < cols; c++) slots.add(new int[]{px0 + c * pw, cz + 1, iz1, 0});
        }
        BlockState fence = Blocks.NETHER_BRICK_FENCE.defaultBlockState();
        BlockState grass = Blocks.GRASS_BLOCK.defaultBlockState();
        int k = 0;
        for (String a : animals) {
            if (k >= slots.size()) {
                p.notes.add("Не вистачило місця для загону: " + a.replace("minecraft:", "") + " (збільш будинок).");
                continue;
            }
            int[] s = slots.get(k++);
            int px = s[0], zA = s[1], zB = s[2];
            boolean north = s[3] == 1;
            for (int x = px + 1; x <= px + pw - 2; x++) for (int z = zA + 1; z <= zB - 1; z++) p.put(x, v.base, z, grass);
            for (int x = px; x <= px + pw - 1; x++) { p.put(x, y0, zA, fence); p.put(x, y0, zB, fence); }
            for (int z = zA; z <= zB; z++) { p.put(px, y0, z, fence); p.put(px + pw - 1, y0, z, fence); }
            int gx = px + pw / 2;
            int gz = north ? zB : zA;
            p.put(gx, y0, gz, Blocks.CRIMSON_FENCE_GATE.defaultBlockState().setValue(FenceGateBlock.FACING, Direction.SOUTH));
            Pen pen = new Pen();
            pen.entity = a;
            pen.x = px + pw / 2.0 + 0.5 - 0.5;
            pen.y = y0;
            pen.z = (zA + zB) / 2.0 + 0.5;
            p.pens.add(pen);
        }
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        for (int x = ix0 + 1; x <= ix1; x += 4) {
            if (p.free(x, v.y1(), cz)) p.put(x, v.y1(), cz, lantern);
        }
        for (int[] s : slots) {
            int lx = s[0] + pw / 2;
            int lz = (s[1] + s[2]) / 2;
            if (p.free(lx, v.y1(), lz)) p.put(lx, v.y1(), lz, lantern);
        }
    }
}
