package com.chatgnome;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(ChatGnomeMod.MODID)
public class ChatGnomeMod {
    public static final String MODID = "chatgnome";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<GnomeEntity>> GNOME = ENTITIES.register("gnome",
            () -> EntityType.Builder.<GnomeEntity>of(GnomeEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.5f).clientTrackingRange(10).build("gnome"));

    public static final RegistryObject<Item> GNOME_EGG = ITEMS.register("gnome_spawn_egg",
            () -> new ForgeSpawnEggItem(GNOME, 0x8B5A2B, 0xE0C080, new Item.Properties()));

    public ChatGnomeMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener(this::onTab);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        MinecraftForge.EVENT_BUS.register(new ChatHandler());
    }

    private void onAttributes(EntityAttributeCreationEvent e) {
        e.put(GNOME.get(), GnomeEntity.createAttributes().build());
    }

    private void onTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            e.accept(GNOME_EGG);
        }
    }
}
