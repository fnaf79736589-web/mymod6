package com.chatgnome;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

final class Categories {
    private Categories() {}

    record Cat(String name, String[] kw) {}

    static final String FOOD = "Їжа";
    static final String MODS = "Механізми";
    static final String OTHER = "Інше";

    static final List<Cat> TABLE = List.of(
            new Cat("Зброя й броня", new String[]{"sword", "bow", "arrow", "helmet", "chestplate", "leggings", "boots", "shield", "trident", "crossbow"}),
            new Cat("Інструменти", new String[]{"pickaxe", "_axe", "shovel", "_hoe", "shears", "bucket", "flint_and_steel", "fishing_rod", "compass", "clock", "spyglass"}),
            new Cat("Камінь", new String[]{"stone", "cobble", "deepslate", "andesite", "diorite", "granite", "brick", "tuff", "basalt", "obsidian", "calcite", "terracotta", "concrete", "prismarine"}),
            new Cat("Руди", new String[]{"ore", "raw_", "ingot", "nugget", "diamond", "emerald", "coal", "lapis", "quartz", "amethyst", "netherite", "copper"}),
            new Cat("Редстоун", new String[]{"redstone", "piston", "repeater", "comparator", "observer", "hopper", "dispenser", "dropper", "lever", "button", "pressure_plate", "rail", "tnt", "daylight"}),
            new Cat("Рослини", new String[]{"seeds", "wheat", "sapling", "flower", "tulip", "orchid", "mushroom", "vine", "fern", "bamboo", "cactus", "kelp", "sugar_cane", "pumpkin", "melon"}),
            new Cat("Дерево", new String[]{"log", "planks", "wood", "stick", "leaves"}),
            new Cat("Земля та пісок", new String[]{"dirt", "sand", "gravel", "clay", "grass", "mud", "podzol", "snow", "mycelium", "netherrack"}),
            new Cat("Дроп мобів", new String[]{"bone", "string", "spider_eye", "gunpowder", "rotten_flesh", "ender_pearl", "blaze", "slime", "feather", "leather", "ghast", "phantom", "shulker", "scute"}),
            new Cat("Декор", new String[]{"glass", "wool", "carpet", "banner", "dye", "bed", "sign", "torch", "lantern", "painting", "frame", "candle", "pot"})
    );

    /** Усі назви категорій у порядку для табличок. */
    static final List<String> NAMES = List.of(
            "Камінь", "Руди", "Земля та пісок", "Дерево", FOOD, "Інструменти", "Зброя й броня",
            "Редстоун", MODS, "Рослини", "Дроп мобів", "Декор", OTHER);

    static String of(ItemStack s) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (id == null) return OTHER;
        if (!id.getNamespace().equals("minecraft")) return MODS;
        if (s.isEdible()) return FOOD;
        String p = id.getPath();
        for (Cat c : TABLE) {
            for (String k : c.kw()) {
                if (p.contains(k)) return c.name();
            }
        }
        return OTHER;
    }
}
