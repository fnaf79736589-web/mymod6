package com.chatgnome;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class LlmClient {
    private LlmClient() {}

    public static String ask(String system, String user) throws Exception {
        String key = Config.apiKey();
        if (key.isBlank()) {
            throw new IllegalStateException("Не задано API ключ. Використай команду /gnome apikey <ключ>");
        }
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.MODEL.get());
        body.addProperty("max_tokens", 4000);
        body.addProperty("system", system);
        JsonArray msgs = new JsonArray();
        JsonObject m = new JsonObject();
        m.addProperty("role", "user");
        m.addProperty("content", user);
        msgs.add(m);
        body.add("messages", msgs);

        HttpURLConnection c = (HttpURLConnection) new URL(Config.API_URL.get()).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(120000);
        c.setDoOutput(true);
        c.setRequestProperty("content-type", "application/json");
        c.setRequestProperty("x-api-key", key);
        c.setRequestProperty("anthropic-version", "2023-06-01");
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
        String resp = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
        if (code / 100 != 2) {
            throw new IOException("API " + code + ": " + (resp.length() > 300 ? resp.substring(0, 300) : resp));
        }
        JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : o.getAsJsonArray("content")) {
            JsonObject part = e.getAsJsonObject();
            if (part.has("type") && "text".equals(part.get("type").getAsString())) {
                sb.append(part.get("text").getAsString());
            }
        }
        return sb.toString();
    }

    public static JsonObject parsePlan(String reply) {
        String s = reply.trim();
        int a = s.indexOf('{');
        int b = s.lastIndexOf('}');
        if (a < 0 || b < a) throw new IllegalArgumentException("Модель не повернула JSON");
        return JsonParser.parseString(s.substring(a, b + 1)).getAsJsonObject();
    }
}
