package com.chatgnome;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.ConfigValue<String> API_KEY = B
            .comment("Ключ Anthropic API. Можна також задати командою /gnome apikey <ключ> або змінною середовища ANTHROPIC_API_KEY")
            .define("apiKey", "");
    public static final ForgeConfigSpec.ConfigValue<String> API_URL = B
            .define("apiUrl", "https://api.anthropic.com/v1/messages");
    public static final ForgeConfigSpec.ConfigValue<String> MODEL = B
            .comment("Модель, що розбирає команди. Швидша/дешевша: claude-haiku-5-5")
            .define("model", "claude-sonnet-5-5");
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PREFIXES = B
            .comment("Повідомлення в чаті, що починаються з цих слів, адресуються гному")
            .defineList("chatPrefixes", List.of("гном", "гноме", "gnome"), o -> o instanceof String);
    public static final ForgeConfigSpec.IntValue BLOCKS_PER_TICK = B
            .comment("Скільки блоків гном ставить за тік під час будівництва")
            .defineInRange("blocksPerTick", 15, 1, 500);
    public static final ForgeConfigSpec.BooleanValue REQUIRE_MATERIALS = B
            .comment("true = гном витрачає блоки зі свого інвентаря при будівництві (треба спершу накопати/принести). false = будує безкоштовно")
            .define("requireMaterials", false);
    public static final ForgeConfigSpec.IntValue MAX_FLOORS = B
            .defineInRange("maxFloors", 40, 1, 80);

    public static final ForgeConfigSpec SPEC = B.build();

    public static String apiKey() {
        String k = API_KEY.get();
        if (k == null || k.isBlank()) k = System.getenv("ANTHROPIC_API_KEY");
        return k == null ? "" : k.trim();
    }
}
